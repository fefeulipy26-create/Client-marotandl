package com.legitclient;

import net.minecraftforge.common.config.Configuration;

import java.io.File;

public class ModConfig {
    public static boolean fps = true;
    public static boolean cps = true;
    public static boolean coords = true;
    public static boolean keystrokes = true;
    public static boolean armor = true;
    public static boolean potions = true;
    public static boolean toggleSprint = false;
    public static boolean zoom = true;
    public static boolean fpsBoostOnStart = false;
    public static int renderDistance = 6;

    private static Configuration cfg;

    public static void load(File file) {
        cfg = new Configuration(file);
        fps = cfg.get("modulos", "fps", true).getBoolean();
        cps = cfg.get("modulos", "cps", true).getBoolean();
        coords = cfg.get("modulos", "coordenadas", true).getBoolean();
        keystrokes = cfg.get("modulos", "keystrokes", true).getBoolean();
        armor = cfg.get("modulos", "armadura", true).getBoolean();
        potions = cfg.get("modulos", "pocoes", true).getBoolean();
        toggleSprint = cfg.get("modulos", "toggleSprint", false).getBoolean();
        zoom = cfg.get("modulos", "zoom", true).getBoolean();
        fpsBoostOnStart = cfg.get("fpsboost", "aplicarAoIniciar", false).getBoolean();
        renderDistance = cfg.get("fpsboost", "distanciaDeRenderizacao", 6).getInt();
        if (cfg.hasChanged()) cfg.save();
    }

    public static void save() {
        if (cfg == null) return;
        cfg.get("modulos", "fps", true).set(fps);
        cfg.get("modulos", "cps", true).set(cps);
        cfg.get("modulos", "coordenadas", true).set(coords);
        cfg.get("modulos", "keystrokes", true).set(keystrokes);
        cfg.get("modulos", "armadura", true).set(armor);
        cfg.get("modulos", "pocoes", true).set(potions);
        cfg.get("modulos", "toggleSprint", false).set(toggleSprint);
        cfg.get("modulos", "zoom", true).set(zoom);
        cfg.get("fpsboost", "aplicarAoIniciar", false).set(fpsBoostOnStart);
        cfg.get("fpsboost", "distanciaDeRenderizacao", 6).set(renderDistance);
        cfg.save();
    }
}

package com.legitclient;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.command.CommandBase;
import net.minecraft.command.ICommandSender;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraftforge.client.ClientCommandHandler;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import java.util.LinkedList;

@Mod(modid = LegitClient.MODID, name = "Legit Client", version = "1.0.0",
        acceptedMinecraftVersions = "[1.8.9]", clientSideOnly = true)
public class LegitClient {
    public static final String MODID = "legitclient";

    public static final KeyBinding KEY_MENU = new KeyBinding("Abrir menu", Keyboard.KEY_RSHIFT, "Legit Client");
    public static final KeyBinding KEY_ZOOM = new KeyBinding("Zoom", Keyboard.KEY_C, "Legit Client");

    private final Minecraft mc = Minecraft.getMinecraft();

    private volatile boolean openMenu;

    private final LinkedList<Long> leftClicks = new LinkedList<Long>();
    private final LinkedList<Long> rightClicks = new LinkedList<Long>();
    private boolean lastLeft, lastRight;

    private boolean zooming;
    private float savedFov;
    private boolean savedSmooth;

    private boolean forcedSprint;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent e) {
        ModConfig.load(e.getSuggestedConfigurationFile());
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent e) {
        ClientRegistry.registerKeyBinding(KEY_MENU);
        ClientRegistry.registerKeyBinding(KEY_ZOOM);
        MinecraftForge.EVENT_BUS.register(this);

        // /lc abre o menu (útil no celular, sem Right Shift)
        ClientCommandHandler.instance.registerCommand(new CommandBase() {
            @Override
            public String getCommandName() {
                return "lc";
            }

            @Override
            public String getCommandUsage(ICommandSender sender) {
                return "/lc";
            }

            @Override
            public void processCommand(ICommandSender sender, String[] args) {
                openMenu = true;
            }

            @Override
            public int getRequiredPermissionLevel() {
                return 0;
            }

            @Override
            public boolean canCommandSenderUseCommand(ICommandSender sender) {
                return true;
            }
        });

        if (ModConfig.fpsBoostOnStart) FpsBoost.apply();
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;

        // CPS (só conta com o jogo em foco, sem tela aberta)
        long now = System.currentTimeMillis();
        boolean l = Mouse.isButtonDown(0);
        boolean r = Mouse.isButtonDown(1);
        if (mc.currentScreen == null) {
            if (l && !lastLeft) leftClicks.add(now);
            if (r && !lastRight) rightClicks.add(now);
        }
        lastLeft = l;
        lastRight = r;
        while (!leftClicks.isEmpty() && now - leftClicks.getFirst() > 1000) leftClicks.removeFirst();
        while (!rightClicks.isEmpty() && now - rightClicks.getFirst() > 1000) rightClicks.removeFirst();

        // Menu
        if (KEY_MENU.isPressed()) openMenu = true;
        if (openMenu && (mc.currentScreen == null || !(mc.currentScreen instanceof MenuScreen))) {
            openMenu = false;
            mc.displayGuiScreen(new MenuScreen());
        }

        if (mc.thePlayer == null) return;

        // Toggle sprint: equivale a segurar a tecla de sprint enquanto anda pra frente
        int sprintCode = mc.gameSettings.keyBindSprint.getKeyCode();
        if (ModConfig.toggleSprint && mc.currentScreen == null
                && mc.gameSettings.keyBindForward.isKeyDown() && !mc.thePlayer.isSneaking()) {
            KeyBinding.setKeyBindState(sprintCode, true);
            forcedSprint = true;
        } else if (forcedSprint) {
            KeyBinding.setKeyBindState(sprintCode, false);
            forcedSprint = false;
        }

        // Zoom (FOV menor + câmera suave, igual ao zoom de OptiFine)
        boolean wantZoom = ModConfig.zoom && mc.currentScreen == null && KEY_ZOOM.isKeyDown();
        if (wantZoom && !zooming) {
            savedFov = mc.gameSettings.fovSetting;
            savedSmooth = mc.gameSettings.smoothCamera;
            mc.gameSettings.fovSetting = Math.max(10f, savedFov / 4f);
            mc.gameSettings.smoothCamera = true;
            zooming = true;
        } else if (!wantZoom && zooming) {
            mc.gameSettings.fovSetting = savedFov;
            mc.gameSettings.smoothCamera = savedSmooth;
            zooming = false;
        }
    }

    @SubscribeEvent
    public void onRender(RenderGameOverlayEvent.Post e) {
        if (e.type != RenderGameOverlayEvent.ElementType.ALL) return;
        if (mc.thePlayer == null || mc.gameSettings.showDebugInfo) return;

        FontRenderer fr = mc.fontRendererObj;
        ScaledResolution sr = e.resolution;
        int y = 4;

        if (ModConfig.fps) {
            fr.drawStringWithShadow("FPS: " + Minecraft.getDebugFPS(), 4, y, 0xFFFFFF);
            y += 10;
        }
        if (ModConfig.cps) {
            fr.drawStringWithShadow("CPS: " + leftClicks.size() + " | " + rightClicks.size(), 4, y, 0xFFFFFF);
            y += 10;
        }
        if (ModConfig.coords) {
            String xyz = String.format("XYZ: %.1f / %.1f / %.1f",
                    mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ);
            fr.drawStringWithShadow(xyz, 4, y, 0xFFFFFF);
            y += 10;
            fr.drawStringWithShadow("Direção: " + mc.thePlayer.getHorizontalFacing().getName(), 4, y, 0xFFFFFF);
            y += 10;
        }

        if (ModConfig.keystrokes) drawKeystrokes(4, y + 6);
        if (ModConfig.armor) drawArmor(sr);
        if (ModConfig.potions) drawPotions(sr);
    }

    private void box(int x, int y, int w, int h, String label, boolean down) {
        FontRenderer fr = mc.fontRendererObj;
        Gui.drawRect(x, y, x + w, y + h, down ? 0x99FFFFFF : 0x66000000);
        fr.drawString(label, x + (w - fr.getStringWidth(label)) / 2, y + (h - 8) / 2,
                down ? 0x000000 : 0xFFFFFF);
    }

    private void drawKeystrokes(int x, int y) {
        int s = 18;
        box(x + 20, y, s, s, "W", mc.gameSettings.keyBindForward.isKeyDown());
        box(x, y + 20, s, s, "A", mc.gameSettings.keyBindLeft.isKeyDown());
        box(x + 20, y + 20, s, s, "S", mc.gameSettings.keyBindBack.isKeyDown());
        box(x + 40, y + 20, s, s, "D", mc.gameSettings.keyBindRight.isKeyDown());
        box(x, y + 40, 29, s, "L " + leftClicks.size(), Mouse.isButtonDown(0));
        box(x + 31, y + 40, 29, s, "R " + rightClicks.size(), Mouse.isButtonDown(1));
        box(x, y + 60, 60, 10, "", mc.gameSettings.keyBindJump.isKeyDown());
    }

    private void drawArmor(ScaledResolution sr) {
        FontRenderer fr = mc.fontRendererObj;
        ItemStack[] stacks = new ItemStack[]{
                mc.thePlayer.inventory.armorInventory[3],
                mc.thePlayer.inventory.armorInventory[2],
                mc.thePlayer.inventory.armorInventory[1],
                mc.thePlayer.inventory.armorInventory[0],
                mc.thePlayer.getHeldItem()
        };
        int x = sr.getScaledWidth() - 20;
        int y = sr.getScaledHeight() / 2 - 45;

        for (ItemStack s : stacks) {
            if (s != null) {
                GlStateManager.pushMatrix();
                RenderHelper.enableGUIStandardItemLighting();
                mc.getRenderItem().renderItemAndEffectIntoGUI(s, x, y);
                RenderHelper.disableStandardItemLighting();
                GlStateManager.popMatrix();
                if (s.isItemStackDamageable()) {
                    String t = String.valueOf(s.getMaxDamage() - s.getItemDamage());
                    fr.drawStringWithShadow(t, x - fr.getStringWidth(t) - 2, y + 4, 0xFFFFFF);
                }
            }
            y += 18;
        }
    }

    private void drawPotions(ScaledResolution sr) {
        FontRenderer fr = mc.fontRendererObj;
        int y = 4;
        for (Object o : mc.thePlayer.getActivePotionEffects()) {
            PotionEffect pe = (PotionEffect) o;
            String name = I18n.format(pe.getEffectName());
            if (pe.getAmplifier() > 0) name += " " + (pe.getAmplifier() + 1);
            String t = name + " " + Potion.getDurationString(pe);
            fr.drawStringWithShadow(t, sr.getScaledWidth() - fr.getStringWidth(t) - 4, y, 0xFFFFFF);
            y += 10;
        }
    }
}

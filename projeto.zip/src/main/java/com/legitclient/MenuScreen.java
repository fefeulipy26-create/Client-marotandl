package com.legitclient;

import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;

import java.io.IOException;

public class MenuScreen extends GuiScreen {
    private static final String[] NAMES = {
            "FPS", "CPS", "Coordenadas", "Keystrokes", "Armadura",
            "Poções", "Toggle Sprint", "Zoom (C)", "FPS boost ao iniciar"
    };

    private boolean get(int id) {
        switch (id) {
            case 0: return ModConfig.fps;
            case 1: return ModConfig.cps;
            case 2: return ModConfig.coords;
            case 3: return ModConfig.keystrokes;
            case 4: return ModConfig.armor;
            case 5: return ModConfig.potions;
            case 6: return ModConfig.toggleSprint;
            case 7: return ModConfig.zoom;
            case 8: return ModConfig.fpsBoostOnStart;
        }
        return false;
    }

    private void toggle(int id) {
        switch (id) {
            case 0: ModConfig.fps = !ModConfig.fps; break;
            case 1: ModConfig.cps = !ModConfig.cps; break;
            case 2: ModConfig.coords = !ModConfig.coords; break;
            case 3: ModConfig.keystrokes = !ModConfig.keystrokes; break;
            case 4: ModConfig.armor = !ModConfig.armor; break;
            case 5: ModConfig.potions = !ModConfig.potions; break;
            case 6: ModConfig.toggleSprint = !ModConfig.toggleSprint; break;
            case 7: ModConfig.zoom = !ModConfig.zoom; break;
            case 8: ModConfig.fpsBoostOnStart = !ModConfig.fpsBoostOnStart; break;
        }
    }

    private String label(int id) {
        return NAMES[id] + ": " + (get(id) ? "ON" : "OFF");
    }

    @Override
    public void initGui() {
        buttonList.clear();
        int top = 32;
        for (int i = 0; i < NAMES.length; i++) {
            int x = width / 2 - 155 + (i % 2) * 160;
            int y = top + (i / 2) * 24;
            buttonList.add(new GuiButton(i, x, y, 150, 20, label(i)));
        }
        buttonList.add(new GuiButton(20, width / 2 - 155, top + 5 * 24, 310, 20, "Aplicar FPS boost agora"));
        buttonList.add(new GuiButton(100, width / 2 - 155, top + 6 * 24, 310, 20, "Concluído"));
    }

    @Override
    protected void actionPerformed(GuiButton button) throws IOException {
        if (button.id < NAMES.length) {
            toggle(button.id);
            button.displayString = label(button.id);
        } else if (button.id == 20) {
            FpsBoost.apply();
            button.displayString = "FPS boost aplicado!";
        } else if (button.id == 100) {
            mc.displayGuiScreen(null);
        }
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        drawDefaultBackground();
        drawCenteredString(fontRendererObj, "Legit Client", width / 2, 14, 0xFFFFFF);
        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    @Override
    public void onGuiClosed() {
        ModConfig.save();
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }
}

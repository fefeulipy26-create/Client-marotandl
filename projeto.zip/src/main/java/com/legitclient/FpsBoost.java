package com.legitclient;

import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.GameSettings;
import org.lwjgl.opengl.Display;

/** Só mexe nas opções de vídeo do próprio jogo (nada de hack). */
public class FpsBoost {
    public static void apply() {
        Minecraft mc = Minecraft.getMinecraft();
        GameSettings gs = mc.gameSettings;
        if (gs == null) return;

        gs.fancyGraphics = false;
        gs.clouds = 0;
        gs.particleSetting = 1;
        gs.ambientOcclusion = 0;
        gs.entityShadows = false;
        gs.useVbo = true;
        gs.enableVsync = false;
        gs.limitFramerate = 260;
        gs.renderDistanceChunks = Math.min(gs.renderDistanceChunks, ModConfig.renderDistance);
        try {
            Display.setVSyncEnabled(false);
        } catch (Throwable ignored) {
        }
        gs.saveOptions();
        if (mc.renderGlobal != null && mc.theWorld != null) {
            mc.renderGlobal.loadRenderers();
        }
    }
}
